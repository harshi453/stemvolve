import { Career, QuizQuestion } from './types';

export const INITIAL_CAREERS: Career[] = [
  {
    id: 'mechanical-engineer',
    name: 'Mechanical Engineer',
    category: 'STEM',
    subCategory: 'Engineering',
    responsibilities: [
      'Design, develop, build, and test mechanical and thermal sensors and devices.',
      'Analyze problems to see how mechanical and thermal devices might help solve a particular problem.',
      'Design or redesign mechanical and thermal devices or subsystems, using computer-aided design (CAD).',
      'Investigate equipment failures or difficulties to diagnose faulty operation and to recommend remedies.'
    ],
    skills: [
      'Advanced Mathematics',
      'Physics',
      'Computer-Aided Design (CAD)',
      'Problem Solving',
      'Creativity',
      'Technical Writing'
    ],
    education: 'Bachelor\'s degree in mechanical engineering or mechanical engineering technology.',
    environment: 'Mechanical engineers generally work in office settings. They may occasionally visit worksites where a problem or piece of equipment needs their personal attention.',
    salary: '$95,000 - $130,000 per year',
    outlook: 'Projected to grow 10% from 2022 to 2032, faster than the average for all occupations.',
    pros: [
      'High earning potential',
      'Diverse career paths (aerospace, automotive, robotics)',
      'Intellectually stimulating work'
    ],
    cons: [
      'Can be high-stress with tight deadlines',
      'Requires continuous learning to keep up with technology',
      'Often involves long hours in front of a computer'
    ],
    tips: 'Focus on building a strong foundation in calculus and physics. Join a robotics club or participate in "Maker" fairs to get hands-on experience.',
    opportunities: [
      'NASA Internships (National)',
      'Lockheed Martin High School Internship Program',
      'Boeing High School Internship',
      'FIRST Robotics Competition (Global)',
      'Science Olympiad',
      'The Cooper Union Summer Art/Engineering Program (NYC)',
      'MIT Beaver Works Summer Institute',
      'Stanford Summer Engineering Academy',
      'Girls Who Code Summer Immersion Program',
      'National Society of Black Engineers (NSBE) Jr. Programs'
    ],
    organizations: [
      'American Society of Mechanical Engineers (ASME)',
      'Society of Automotive Engineers (SAE)',
      'Society of Women Engineers (SWE)',
      'National Society of Black Engineers (NSBE)'
    ]
  },
  {
    id: 'graphic-designer',
    name: 'Graphic Designer',
    category: 'Non-STEM',
    subCategory: 'Arts & Design',
    responsibilities: [
      'Create visual concepts, using computer software or by hand, to communicate ideas that inspire, inform, and captivate consumers.',
      'Develop the overall layout and production design for applications such as advertisements, brochures, magazines, and reports.',
      'Meet with clients or art directors to determine the scope of a project.'
    ],
    skills: [
      'Adobe Creative Suite (Photoshop, Illustrator, InDesign)',
      'Typography',
      'Color Theory',
      'Communication',
      'Time Management'
    ],
    education: 'Bachelor\'s degree in graphic design or a related field. A portfolio of work is often more important than the degree.',
    environment: 'Graphic designers work in studios, offices, or from home. Many are self-employed (freelance).',
    salary: '$50,000 - $85,000 per year',
    outlook: 'Projected to grow 3% from 2022 to 2032, slower than the average.',
    pros: [
      'Creative freedom',
      'Ability to work remotely',
      'Seeing your work in the public eye'
    ],
    cons: [
      'Subjective feedback can be frustrating',
      'Tight deadlines and high competition',
      'Long hours sitting and staring at screens'
    ],
    tips: 'Start building a portfolio early. Take on small projects for friends, family, or local non-profits to practice your skills.',
    opportunities: [
      'Adobe Creative Residency Community Fund',
      'Scholastic Art & Writing Awards',
      'Local Museum Volunteer Programs',
      'High School Yearbook Staff',
      'AIGA High School Mentorship Programs',
      'Summer Art Intensive at Cooper Union',
      'RISD Pre-College Program',
      'Pratt Institute Pre-College',
      'National YoungArts Foundation',
      'Behance Student Showcases'
    ],
    organizations: [
      'AIGA (The Professional Association for Design)',
      'Graphic Artists Guild',
      'Society for Experiential Graphic Design (SEGD)'
    ]
  }
];

export const QUIZ_QUESTIONS: QuizQuestion[] = [
  {
    id: 1,
    question: "When you walk into a room with a broken machine, what's your first instinct?",
    options: [
      { text: "Wonder about the physics of why it stopped working.", weights: { 'Engineering': 2, 'STEM': 1 } },
      { text: "Think about how the machine's design could be more intuitive.", weights: { 'Arts & Design': 2, 'Non-STEM': 1 } },
      { text: "Try to find the manual and follow the steps to fix it.", weights: { 'IT': 2, 'STEM': 1 } },
      { text: "Consider how the broken machine affects the people in the room.", weights: { 'Healthcare': 2, 'Non-STEM': 1 } }
    ]
  },
  {
    id: 2,
    question: "Which of these sounds like a more satisfying Saturday afternoon?",
    options: [
      { text: "Solving a complex logic puzzle or coding a small game.", weights: { 'IT': 2, 'STEM': 1 } },
      { text: "Sketching characters or redesigning a room's layout.", weights: { 'Arts & Design': 2, 'Non-STEM': 1 } },
      { text: "Volunteering at a local clinic or animal shelter.", weights: { 'Healthcare': 2, 'STEM': 1 } },
      { text: "Building a model bridge or taking apart an old clock.", weights: { 'Engineering': 2, 'STEM': 1 } }
    ]
  },
  // Adding more questions to reach 20 as requested
  {
    id: 3,
    question: "If you were writing a book, what would it be about?",
    options: [
      { text: "A technical guide on how a futuristic city functions.", weights: { 'Engineering': 2 } },
      { text: "A collection of stories about human resilience and healing.", weights: { 'Healthcare': 2 } },
      { text: "A visual novel with experimental art styles.", weights: { 'Arts & Design': 2 } },
      { text: "A mystery solved through digital forensic evidence.", weights: { 'IT': 2 } }
    ]
  },
  {
    id: 4,
    question: "What's your favorite part of a group project?",
    options: [
      { text: "Calculating the data and ensuring accuracy.", weights: { 'STEM': 2 } },
      { text: "Making the presentation look professional and beautiful.", weights: { 'Non-STEM': 2 } },
      { text: "Organizing the team and managing the timeline.", weights: { 'Non-STEM': 1, 'Business': 1 } },
      { text: "Researching the 'why' behind the topic.", weights: { 'STEM': 1 } }
    ]
  },
  {
    id: 5,
    question: "You find a mysterious old map. What do you do?",
    options: [
      { text: "Analyze the terrain and geological features.", weights: { 'STEM': 2 } },
      { text: "Appreciate the calligraphy and artistic detail.", weights: { 'Non-STEM': 2 } },
      { text: "Try to decode the hidden symbols using logic.", weights: { 'IT': 1, 'STEM': 1 } },
      { text: "Imagine the history of the people who lived there.", weights: { 'Non-STEM': 1 } }
    ]
  },
  {
    id: 6,
    question: "Which news headline catches your eye first?",
    options: [
      { text: "New Breakthrough in Quantum Computing.", weights: { 'IT': 2, 'STEM': 1 } },
      { text: "Revolutionary New Treatment for Rare Disease.", weights: { 'Healthcare': 2, 'STEM': 1 } },
      { text: "The Future of Sustainable Architecture.", weights: { 'Engineering': 2, 'STEM': 1 } },
      { text: "How Art is Shaping Modern Social Movements.", weights: { 'Arts & Design': 2, 'Non-STEM': 1 } }
    ]
  },
  {
    id: 7,
    question: "If you could have a superpower, which would it be?",
    options: [
      { text: "The ability to understand and speak all languages.", weights: { 'Non-STEM': 2 } },
      { text: "The ability to see through objects to their inner workings.", weights: { 'Engineering': 2, 'STEM': 1 } },
      { text: "The ability to heal any wound instantly.", weights: { 'Healthcare': 2, 'STEM': 1 } },
      { text: "The ability to manipulate digital data with your mind.", weights: { 'IT': 2, 'STEM': 1 } }
    ]
  },
  {
    id: 8,
    question: "What's your preferred way to solve a conflict?",
    options: [
      { text: "Looking at the facts and data objectively.", weights: { 'STEM': 2 } },
      { text: "Listening to everyone's feelings and finding empathy.", weights: { 'Non-STEM': 2 } },
      { text: "Finding a creative compromise that pleases everyone.", weights: { 'Non-STEM': 1 } },
      { text: "Systematically breaking down the problem into parts.", weights: { 'STEM': 1 } }
    ]
  },
  {
    id: 9,
    question: "What kind of museum would you visit first?",
    options: [
      { text: "A Science and Technology Center.", weights: { 'STEM': 2 } },
      { text: "A Modern Art Gallery.", weights: { 'Non-STEM': 2 } },
      { text: "A Natural History Museum.", weights: { 'STEM': 1 } },
      { text: "A Design and Fashion Museum.", weights: { 'Non-STEM': 1 } }
    ]
  },
  {
    id: 10,
    question: "You're building a LEGO set. How do you do it?",
    options: [
      { text: "Follow the instructions exactly, step-by-step.", weights: { 'Engineering': 1, 'STEM': 1 } },
      { text: "Look at the picture and try to figure it out yourself.", weights: { 'Engineering': 2 } },
      { text: "Throw the instructions away and build something unique.", weights: { 'Arts & Design': 2, 'Non-STEM': 1 } },
      { text: "Organize all the pieces by color and size first.", weights: { 'IT': 1, 'STEM': 1 } }
    ]
  },
  {
    id: 11,
    question: "What's your favorite school subject (or the one you find most interesting)?",
    options: [
      { text: "Math or Physics.", weights: { 'Engineering': 2, 'STEM': 1 } },
      { text: "Biology or Chemistry.", weights: { 'Healthcare': 2, 'STEM': 1 } },
      { text: "English, History, or Art.", weights: { 'Arts & Design': 2, 'Non-STEM': 1 } },
      { text: "Computer Science or Robotics.", weights: { 'IT': 2, 'STEM': 1 } }
    ]
  },
  {
    id: 12,
    question: "If you were stranded on an island, what's your priority?",
    options: [
      { text: "Building a sturdy shelter and a water filtration system.", weights: { 'Engineering': 2 } },
      { text: "Identifying edible plants and checking for injuries.", weights: { 'Healthcare': 2 } },
      { text: "Keeping a visual journal of the island's beauty.", weights: { 'Arts & Design': 2 } },
      { text: "Creating a logical signal system for rescue.", weights: { 'IT': 2 } }
    ]
  },
  {
    id: 13,
    question: "What do you notice first about a new app?",
    options: [
      { text: "How fast it loads and how smooth the code feels.", weights: { 'IT': 2 } },
      { text: "The colors, fonts, and overall visual appeal.", weights: { 'Arts & Design': 2 } },
      { text: "How useful it is for solving a real-world problem.", weights: { 'Engineering': 1, 'Healthcare': 1 } },
      { text: "How it connects people and builds community.", weights: { 'Non-STEM': 2 } }
    ]
  },
  {
    id: 14,
    question: "Which of these hobbies sounds most appealing?",
    options: [
      { text: "Gardening and studying plant growth.", weights: { 'Healthcare': 1, 'STEM': 1 } },
      { text: "Photography and editing photos.", weights: { 'Arts & Design': 2 } },
      { text: "Building computers or fixing electronics.", weights: { 'IT': 2 } },
      { text: "Woodworking or metalworking.", weights: { 'Engineering': 2 } }
    ]
  },
  {
    id: 15,
    question: "How do you feel about rules?",
    options: [
      { text: "They are necessary parameters for a system to work.", weights: { 'STEM': 1 } },
      { text: "They are meant to be questioned and creatively interpreted.", weights: { 'Non-STEM': 2 } },
      { text: "They provide a safe framework for helping others.", weights: { 'Healthcare': 1 } },
      { text: "They are logic gates that guide behavior.", weights: { 'IT': 1 } }
    ]
  },
  {
    id: 16,
    question: "What's your dream workspace?",
    options: [
      { text: "A high-tech lab with advanced equipment.", weights: { 'STEM': 2 } },
      { text: "A bright, open studio filled with art supplies.", weights: { 'Non-STEM': 2 } },
      { text: "A bustling hospital or community center.", weights: { 'Healthcare': 2 } },
      { text: "A quiet, focused space with multiple monitors.", weights: { 'IT': 2 } }
    ]
  },
  {
    id: 17,
    question: "What kind of puzzles do you enjoy most?",
    options: [
      { text: "Sudoku or math-based puzzles.", weights: { 'STEM': 2 } },
      { text: "Jigsaw puzzles or visual patterns.", weights: { 'Non-STEM': 2 } },
      { text: "Word games or riddles.", weights: { 'Non-STEM': 1 } },
      { text: "Mechanical puzzles like a Rubik's cube.", weights: { 'Engineering': 2 } }
    ]
  },
  {
    id: 18,
    question: "If you could invent something, what would it be?",
    options: [
      { text: "A clean energy source that powers the world.", weights: { 'Engineering': 2, 'STEM': 1 } },
      { text: "A device that allows people to share their dreams.", weights: { 'Arts & Design': 2, 'Non-STEM': 1 } },
      { text: "A cure for a previously incurable disease.", weights: { 'Healthcare': 2, 'STEM': 1 } },
      { text: "An AI that can solve any logical problem.", weights: { 'IT': 2, 'STEM': 1 } }
    ]
  },
  {
    id: 19,
    question: "How do you prefer to learn something new?",
    options: [
      { text: "Reading a detailed technical manual.", weights: { 'STEM': 1 } },
      { text: "Watching a visual demonstration or video.", weights: { 'Non-STEM': 1 } },
      { text: "Doing it yourself and learning from mistakes.", weights: { 'Engineering': 1 } },
      { text: "Discussing it with others and sharing perspectives.", weights: { 'Non-STEM': 1 } }
    ]
  },
  {
    id: 20,
    question: "What's the most important thing in a career?",
    options: [
      { text: "Innovation and pushing the boundaries of what's possible.", weights: { 'STEM': 2 } },
      { text: "Expression and creating something beautiful or meaningful.", weights: { 'Non-STEM': 2 } },
      { text: "Service and making a direct impact on people's lives.", weights: { 'Healthcare': 2 } },
      { text: "Efficiency and optimizing systems for better performance.", weights: { 'IT': 2 } }
    ]
  }
];
