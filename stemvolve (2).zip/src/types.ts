export interface Career {
  id: string;
  name: string;
  category: 'STEM' | 'Non-STEM';
  subCategory: string;
  responsibilities: string[];
  skills: string[];
  education: string;
  environment: string;
  salary: string;
  outlook: string;
  pros: string[];
  cons: string[];
  tips: string;
  opportunities: string[];
  organizations: string[];
}

export interface QuizQuestion {
  id: number;
  question: string;
  options: {
    text: string;
    weights: { [key: string]: number }; // key is subCategory or category
  }[];
}
